Model and label (improved)
